package com.nutrivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutrivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutrivoApplication.class, args);
	}

}
