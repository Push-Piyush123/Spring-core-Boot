package com.nutrivo.enums;

public enum NutritionBasis {
    PER_100G, PER_100ML, PER_SERVING
}
