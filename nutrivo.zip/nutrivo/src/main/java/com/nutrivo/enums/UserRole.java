package com.nutrivo.enums;

public enum UserRole {
    USER, ADMIN
}
