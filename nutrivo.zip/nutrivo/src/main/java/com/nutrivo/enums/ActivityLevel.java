package com.nutrivo.enums;

public enum ActivityLevel {
    SEDENTARY, LIGHT, NORMAL, MODERATE, ACTIVE, VERY_ACTIVE
}
