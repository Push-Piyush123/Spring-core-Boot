package com.project.PhoneService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.PhoneService.entity.Phone;

@Repository
public interface PhoneDao extends JpaRepository<Phone, Long> {

}
