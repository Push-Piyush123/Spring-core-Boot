package com.project.PhoneService.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Phone {
	
	@Id
	private Long phoneId;
	private String model;
	private String color;
	private Double price;
	public Phone(Long phoneId, String model, String color, Double price) {
		super();
		this.phoneId = phoneId;
		this.model = model;
		this.color = color;
		this.price = price;
	}
	public Phone() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getPhoneId() {
		return phoneId;
	}
	public void setPhoneId(Long phoneId) {
		this.phoneId = phoneId;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	
}
