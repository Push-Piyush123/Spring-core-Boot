package com.project.PhoneService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.PhoneService.entity.Phone;
import com.project.PhoneService.service.PhoneService;

@RestController
@RequestMapping("/phone")
public class PhoneController {
		
	@Autowired
	PhoneService phoneservice;
	
	@GetMapping("/home")
	public String getHome() {
		return "Welcome to Phone service";
	}
	
	@GetMapping("/get")
	public List<Phone> getAllPhones() {
		return phoneservice.getPhones();
	}
	
	@GetMapping("/get/id/{id}")
	public Phone getPhone( @PathVariable Long id) {
		return phoneservice.getPhone(id);
	}
	
	@PostMapping("/add")
	public Phone addPhone(@RequestBody Phone phone) {
		return phoneservice.addPhone(phone);
	}
	
	@PostMapping("/addPhones")
	public List<Phone> addPhone(@RequestBody List<Phone> phones) {
		return phoneservice.addPhones(phones);
	}
	
	@GetMapping("/get/price/{price}")
	public Phone getPhoneByprice( @PathVariable Double price) {
			return phoneservice.getPhoneByPrice(price);
	}
	
}
