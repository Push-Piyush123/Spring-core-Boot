package com.project.PhoneService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.PhoneService.Dao.PhoneDao;
import com.project.PhoneService.entity.Phone;

@Service
public class PhoneService {
	
	@Autowired
	PhoneDao phonedao;
	
	public List<Phone> getPhones() {
		return phonedao.findAll();
	}
	
	public Phone getPhone(Long id) {
		return phonedao.findById(id).orElse(null);
	}
	
	public Phone addPhone(Phone phone) {
		 phonedao.save(phone);
		 return phone;
	}
	
	public List<Phone> addPhones(List<Phone> phones) {
		 phonedao.saveAll(phones);
		 return phones;
	}
	
	public Phone getPhoneByPrice(Double price) {
		Long id=null;
		if(price<2000000) {
			id=(long) 101;
		}else if(price<=3000000) {
			id=(long) 102;
		}
		else if(price>3000000) {
			id=(long) 103;
		}
		return getPhone(id);
	}
	
}
