package pack;

public class hello {
	public static void main(String[] args) {
		System.out.print("hellow");;
	}
}
