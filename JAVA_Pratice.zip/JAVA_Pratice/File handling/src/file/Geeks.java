package file;
import java.io.*;


public class Geeks {
    public static void main(String[] args) throws Exception {

        BufferedReader f = new BufferedReader(
                new FileReader("C:\\Users\\Rudra\\Desktop\\file handle\\myfile.txt")
        );

        String line;
        while ((line = f.readLine()) != null) {
            System.out.println(line);
        }

        f.close();
    }
}