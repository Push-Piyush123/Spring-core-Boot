package LinkedList;

import java.util.Scanner;

class Node{
	int data;
	Node next;   // refrence variable ka data type vo hota hai jiska o address return kr rha hai.
	Node(int d){
		data=d;
		// next by default null
	}
}

class sll{
	Node start; // means head we want 1 head only that why we are writing sll class 
	Scanner sc = new Scanner(System.in);
	Node createNode(int d) {
		return new Node(d);
	}
	
	 void insertNodeAtFirst() {
	        
	        System.out.print("Enter Data:");
	        if (start == null) {
	            start = createNode(sc.nextInt());
	        } else {
	        	  Node t = createNode(sc.nextInt());
	              t.next=start;
	              start=t;
	        }
	    }
	
	void insertnode() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the data");
		
		if(start==null) {
			start=createNode(sc.nextInt());
		}else {
			Node t=start;
			while(t.next!=null) {
				t=t.next;
			}
			t.next=createNode(sc.nextInt());
		}
	}
	
	void deleteNodeAtFirst() {
		if(start==null) {
			System.out.println("List is empty");
			return;
		}
		Node t=start;
		start=start.next;
		t.next=null;
		System.out.println("deleted node");
	}
	
	void deleteNodeAtLast() {
		
		Node t=start;
		if(start==null) {
			System.out.println("List is empty");
			return;
		}
		if(start.next==null) { // only 1 node
			start=null;
			System.out.println("deleted node");
			return;
		}
		while(t.next.next!=null) {  // fail at only 1 code in list for this we handle in upper if statement
			t=t.next;
		}
		t.next=null;
		System.out.println("deleted node");
		
	}
	
	void displayAllNodes(){
        Node t=start;
        
        while(t!=null)
        {
        System.out.print(t.data+" --> ");
        t=t.next;
        }
    }
	void reverse() {
		int arr[]=new int[100];
		Node t=start;
		int i=0;
		while(t!=null) {
			arr[i++]=t.data;
			t=t.next;
		}
		System.out.println("Reverse List is  ");
		for(int j=i-1;j>=0;j--) {
			System.out.print(arr[j]+" --> ");
		}
		
	}
	
	void deleteAtMiddle() {
		Node t=start;
		if(start==null) {
			System.out.println("List is empty");
			return;
		}
		System.out.println("Enter the data which you want to delete ");
		int data=sc.nextInt();
		Node prev = null;
		Node curr=start;
		while(curr!=null) {
			if(curr.data==data) {
				prev.next=curr.next;
				curr.next=null;
				System.out.println("Delected succesfully");
				return;
			}
			prev=curr;
			curr=curr.next;
		}
		}
	
}

public class Basiclinkedlist{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		sll s1=new sll();
		
		while(true) {
			System.out.println("\nMenu :");
			System.out.println("1.insert at last");
			System.out.println("2.display");
			System.out.println("3.insert at first");
			System.out.println("4.delete first");
			System.out.println("5.delete last");
			System.out.println("6.Reverse display");
			System.out.println("7.delete at middle");
			System.out.println("100.exit");
			
			System.out.print("enetr your choice :");
			int choice=sc.nextInt();
			
			switch(choice) {
			case 1:s1.insertnode();
				break;
			case 2:s1.displayAllNodes();
				break;
			case 3:s1.insertNodeAtFirst();
				break;
			case 4:s1.deleteNodeAtFirst();
				break;
			case 5:s1.deleteNodeAtLast();
				break;
			case 6:s1.reverse();
					break;
			case 7:s1.deleteAtMiddle();
				break;
			default:System.out.println("Enter valid choice");
				break;
			case 100:System.out.println("Exit");
				System.exit(0);
			}
		}
	}
	
}