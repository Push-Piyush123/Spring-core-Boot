package Programe3;

class Person {
 String name = "Piyush Lende";

 void display() {
     System.out.println("Name: " + name);
 }
}

class Student extends Person {
 int marks = 85;

 void show() {
     System.out.println("Marks: " + marks);
 }
}

public class SingleInheritance {
 public static void main(String[] args) {
     Student s = new Student();
     s.display();
     s.show();
 }
}