package Programe3;


class Sports {
 void play() {
     System.out.println("Playing a sport...");
 }
}

class Football extends Sports {
	@Override
    void play() {
     System.out.println("Playing Football - Piyush loves football");
 }
}

class Basketball extends Sports {
	@Override
    void play() {
     System.out.println("Playing Basketball - Fast and energetic game");
 }
}

class Rugby extends Sports {
	@Override
    void play() {
     System.out.println("Playing Rugby - Strong and physical game");
 }
}

public class SportsTest {
 public static void main(String[] args) {

     Sports s;

     s = new Football();
     s.play();

     s = new Basketball();
     s.play();

     s = new Rugby();
     s.play();
 }
}
