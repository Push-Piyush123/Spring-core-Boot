package Programe3;

interface Study {
 void studyDetails();
}

interface Sportsas {
 void sportsDetails();
}

class Studennt implements Study, Sports {
 public void studyDetails() {
     System.out.println("Piyush studies Computer Engineering");
 }

 public void sportsDetails() {
     System.out.println("Piyush plays Carrom");
 }
}

public class MultipleInheritance {
 public static void main(String[] args) {
     Studennt s = new Studennt();
     s.studyDetails();
     s.sportsDetails();
 }
}