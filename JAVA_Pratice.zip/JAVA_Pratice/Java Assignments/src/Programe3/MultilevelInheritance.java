package Programe3;


class Company {
 String companyName = "TCS";
}

class Manager extends Company {
 String managerName = "Piyush Lende";
}

class Employee extends Manager {
 int salary = 30000;

 void display() {
     System.out.println("Company: " + companyName);
     System.out.println("Manager: " + managerName);
     System.out.println("Salary: " + salary);
 }
}

public class MultilevelInheritance {
 public static void main(String[] args) {
     Employee e = new Employee();
     e.display();
 }
}