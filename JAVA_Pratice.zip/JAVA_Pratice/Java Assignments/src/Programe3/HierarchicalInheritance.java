package Programe3;

class Bank {
 String bankName = "SBI";
}

class SavingsAccount extends Bank {
 void showSavings() {
     System.out.println("Savings Account in " + bankName);
 }
}

class CurrentAccount extends Bank {
 void showCurrent() {
     System.out.println("Current Account in " + bankName);
 }
}

public class HierarchicalInheritance {
 public static void main(String[] args) {
     SavingsAccount s = new SavingsAccount();
     CurrentAccount c = new CurrentAccount();

     s.showSavings();
     c.showCurrent();
 }
}