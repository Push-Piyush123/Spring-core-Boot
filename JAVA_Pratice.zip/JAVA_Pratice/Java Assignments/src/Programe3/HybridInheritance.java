package Programe3;


class Animal {
 String name = "Animal";

 void eat() {
     System.out.println("Animals eat food");
 }
}

class Mammal extends Animal {
 void walk() {
     System.out.println("Mammals can walk");
 }
}

//Hierarchical part
class Bird extends Animal {
 void fly() {
     System.out.println("Birds can fly");
 }
}

//Multilevel part
class Dog extends Mammal {
 void bark() {
     System.out.println("Dog barks - Example by Piyush Lende");
 }
}

public class HybridInheritance {
 public static void main(String[] args) {

     // Multilevel 
     Dog d = new Dog();
     d.eat();
     d.walk();
     d.bark();

     System.out.println();

     // Hierarchical 
     Bird b = new Bird();
     b.eat();
     b.fly();
 }
}