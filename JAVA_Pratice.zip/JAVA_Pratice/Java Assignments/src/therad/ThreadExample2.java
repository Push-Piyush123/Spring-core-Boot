package therad;

//Program by Piyush Lende - Even and Odd using Threads

class EvenThread extends Thread {
 public void run() {
     System.out.println("Even Numbers:");
     for (int i = 1; i <= 20; i++) {
         if (i % 2 == 0) {
             System.out.print(i + " ");
         }
     }
 }
}

class OddThread extends Thread {
 public void run() {
     System.out.println("\nOdd Numbers:");
     for (int i = 1; i <= 20; i++) {
         if (i % 2 != 0) {
             System.out.print(i + " ");
         }
     }
 }
}

public class ThreadExample2 {
 public static void main(String[] args) {

     EvenThread t1 = new EvenThread();
     OddThread t2 = new OddThread();

     t1.start(); // start even thread
     t2.start(); // start odd thread
 }
}