package keyword;


class Person {
 String name;

 Person(String name) {
     this.name = name;
     System.out.println("Person Constructor Called");
 }

 void show() {
     System.out.println("This is Person class method");
 }
}

class Employee extends Person {
 String job;

 Employee(String name, String job) {
     super(name);   
     this.job = job;
 }

 void display() {
     System.out.println("Name: " + name);
     System.out.println("Job: " + job);

     super.show();   
 }
}

public class SuperExample {
 public static void main(String[] args) {
     Employee e = new Employee("Piyush Lende", "Computer Engineer");
     e.display();
 }
}