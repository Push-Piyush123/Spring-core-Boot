package keyword;


final class Bank {   //cant inherit

 final int interestRate = 7; // constant

 Bank() {
     System.out.println("Bank Constructor Called");
 }

 final void showRate() {   // 3. final method cant overridden)
     System.out.println("Interest Rate: " + interestRate + "%");
 }
}

class Customer {
 final int id;

 Customer(int id) {
     this.id = id;
 }

 void display() {
     System.out.println("Customer ID: " + id);
 }
}

public class FinalExample {
 public static void main(String[] args) {

     Bank b = new Bank();
     b.showRate();

     System.out.println();

     Customer c1 = new Customer(101);
     c1.display();
 }
}