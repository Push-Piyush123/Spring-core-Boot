package keyword;


class College {

 // 1. static variable (shared by all objects)
 static String collegeName = "MITAOE";

 int rollNo;
 String name;

 College(int rollNo, String name) {
     this.rollNo = rollNo;
     this.name = name;
 }

 // 2. static method cant acces non static var
 static void showCollege() {
     System.out.println("College Name: " + collegeName);
 }

 // 3. static block runs once
 static {
     System.out.println("Static Block Executed - Piyush Lende");
 }

 void display() {
     System.out.println("Roll No: " + rollNo);
     System.out.println("Name: " + name);
     System.out.println("College: " + collegeName);
 }
}

public class StaticExample {
 public static void main(String[] args) {

     // calling static method without object
     College.showCollege();

     System.out.println();

     College s1 = new College(90, "Piyush Lende");
     College s2 = new College(91, "Rahul");

     s1.display();
     System.out.println();
     s2.display();
 }
}