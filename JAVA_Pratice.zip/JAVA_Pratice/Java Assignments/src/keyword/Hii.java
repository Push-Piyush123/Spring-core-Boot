package keyword;

 interface H {
	 static void h1() {
		 System.out.println("hiiiii");
	 }
    default void m() {
    	System.out.println("def called");
    }
}

class Hii implements H{
	public static void main(String[] args) {
		Hii h=new Hii();
		h.m();
		H.h1();
	}
}