package keyword;

class Student {
 int rollNo;
 String name;

 Student(int rollNo, String name) {
     this.rollNo = rollNo;   
     this.name = name;
 }

 void display() {
     System.out.println("Roll No: " + this.rollNo);
     System.out.println("Name: " + this.name);
 }
}

public class ThisExample {
 public static void main(String[] args) {
     Student s1 = new Student(90, "Piyush Lende");
     s1.display();
 }
}