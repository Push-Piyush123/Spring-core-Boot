package polymorphism;


class Shape {
 void draw() {
     System.out.println("Drawing shape");
 }
}

class Circle extends Shape {
 void draw() {
     System.out.println("Drawing Circle");
 }
}

class Rectangle extends Shape {
 void draw() {
     System.out.println("Drawing Rectangle");
 }
}

public class RuntimePolyExample {
 public static void main(String[] args) {

     Shape s;

     s = new Circle();
     s.draw();

     s = new Rectangle();
     s.draw();
 }
}