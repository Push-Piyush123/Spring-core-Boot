package polymorphism;

class Vehicle {
 void speedUp() {
     System.out.println("Vehicle is speeding up");
 }
}

class Car extends Vehicle {
 void speedUp() {
     System.out.println("Car speed increases rapidly - Driven by Piyush Lende");
 }
}

class Bicycle extends Vehicle {
 void speedUp() {
     System.out.println("Bicycle speed increases slowly by pedaling");
 }
}

public class VehicleTest {
 public static void main(String[] args) {

     Vehicle v;

     v = new Car();
     v.speedUp();

     v = new Bicycle();
     v.speedUp();
 }
}