package polymorphism;


class Animal {
 void sound() {
     System.out.println("Animals make sound");
 }
}

class Dog extends Animal {
 void sound() {
     System.out.println("Dog barks");
 }
}

public class OverridingExample {
 public static void main(String[] args) {
     Animal a = new Dog();  
     a.sound();
 }
}
