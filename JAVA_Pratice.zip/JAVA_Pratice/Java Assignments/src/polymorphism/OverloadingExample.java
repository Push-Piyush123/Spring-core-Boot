package polymorphism;


class Calculator {

 int add(int a, int b) {
     return a + b;
 }

 int add(int a, int b, int c) {
     return a + b + c;
 }

 double add(double a, double b) {
     return a + b;
 }
}

public class OverloadingExample {
 public static void main(String[] args) {
     Calculator c = new Calculator();

     System.out.println("Sum1: " + c.add(10, 20));
     System.out.println("Sum2: " + c.add(10, 20, 30));
     System.out.println("Sum3: " + c.add(10.5, 20.5));
 }
}
