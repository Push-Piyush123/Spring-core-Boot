package assignment6;
import java.util.*;

public class anagram {
    public static void main(String[] args) {
    	String s="piyush";
    	String s2="shuyiP";
    	HashMap<Character,Integer>map=new HashMap<>();
    	if(s.length()!=s2.length()) {
    		System.out.println("not anagram");
    		return;
    	}
    	for(int i=0;i<s.length();i++) {
    		map.put(s.charAt(i), map.getOrDefault(s.charAt(i), 0)+1);
    	}
    		
//    	for(int i=0;i<s.length();i++) {
//    		map.put(s2.charAt(i), map.getOrDefault(s.charAt(i), 0)-1);
//    	}
    		
    	for(Character c:map.keySet()) {
    		System.out.println(c);
    	}
    }
}
