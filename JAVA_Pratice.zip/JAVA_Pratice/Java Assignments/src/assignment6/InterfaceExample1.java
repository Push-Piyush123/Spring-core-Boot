package assignment6;


interface Vehicle {
 void start(); // abstract method
}

class Car implements Vehicle {
 public void start() {
     System.out.println("Car starts with key - Piyush Lende");
 }
}

public class InterfaceExample1 {
 public static void main(String[] args) {
     Car c = new Car();
     c.start();
 }
}