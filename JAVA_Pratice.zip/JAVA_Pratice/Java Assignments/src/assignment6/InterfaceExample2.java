package assignment6;


interface Study {
 void study();
}

interface Sports {
 void play();
}

class Piyush implements Study, Sports {
 public void study() {
     System.out.println("Piyush Lende is studying");
 }

 public void play() {
     System.out.println("Piyush Lende plays cricket");
 }
}

public class InterfaceExample2 {
 public static void main(String[] args) {
     Piyush s = new Piyush();
     s.study();
     s.play();
 }
}