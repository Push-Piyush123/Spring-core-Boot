package assignment6;


public class LambdaExample3 {
 public static void main(String[] args) {

     Runnable r = () -> {
         System.out.println("Thread is running - Piyush Lende");
     };

     Thread t = new Thread(r);
     t.start();
 }
}