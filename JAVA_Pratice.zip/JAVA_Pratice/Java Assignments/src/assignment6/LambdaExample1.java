package assignment6;


interface MyInterface {
 void show();
}

public class LambdaExample1 {
 public static void main(String[] args) {

     MyInterface obj = () -> {
         System.out.println("Hello from Lambda - Piyush Lende");
     };

     obj.show();
 }
}