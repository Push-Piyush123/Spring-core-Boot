package assignment6;

abstract class Bank {
 abstract int getRateOfInterest();
}

class SBI extends Bank {
 int getRateOfInterest() {
     return 7;
 }
}

class HDFC extends Bank {
 int getRateOfInterest() {
     return 8;
 }
}

public class AbstractExample3 {
 public static void main(String[] args) {

     Bank b;

     b = new SBI();
     System.out.println("SBI Interest: " + b.getRateOfInterest() + "%");

     b = new HDFC();
     System.out.println("HDFC Interest: " + b.getRateOfInterest() + "%");
 }
}