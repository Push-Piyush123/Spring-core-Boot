package assignment6;

//Abstract Class with Constructor

abstract class Person {
 String name;

 Person(String name) {
     this.name = name;
     System.out.println("Person Constructor Called");
 }

 abstract void display();
}

class Student extends Person {

 Student(String name) {
     super(name); 
 }

 void display() {
     System.out.println("Student Name: " + name);
 }
}

public class AbstractExample2 {
 public static void main(String[] args) {
     Student s = new Student("Piyush Lende");
     s.display();
 }
}