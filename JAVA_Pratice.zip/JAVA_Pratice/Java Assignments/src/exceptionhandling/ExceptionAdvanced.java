package exceptionhandling;

class Check {
    void validate(int age) throws ArithmeticException {

        if (age < 18) {
            throw new ArithmeticException("Not eligible");
        } else {
            System.out.println("Eligible - Piyush Lende");
        }
    }
}

public class ExceptionAdvanced {
    public static void main(String[] args) {

        Check c = new Check();

        try {
            c.validate(15);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }
}