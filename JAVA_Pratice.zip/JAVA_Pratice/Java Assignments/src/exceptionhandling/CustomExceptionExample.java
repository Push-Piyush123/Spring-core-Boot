package exceptionhandling;


class InvalidAgeException extends Exception {

 InvalidAgeException(String message) {
     super(message);
 }
}

public class CustomExceptionExample {

 static void checkAge(int age) throws InvalidAgeException {

     if (age < 18) {
         throw new InvalidAgeException("Age is less than 18 - Not eligible");
     } else {
         System.out.println("Eligible for voting - Piyush Lende");
     }
 }

 public static void main(String[] args) {

     try {
         checkAge(16);
     } catch (InvalidAgeException e) {
         System.out.println("Exception: " + e.getMessage());
     }
 }
}