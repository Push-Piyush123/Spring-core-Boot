package exceptionhandling;

public class ExceptionFinally {
    public static void main(String[] args) {

        try {
            int a = 10 / 2;
            System.out.println("Result: " + a);
        } catch (Exception e) {
            System.out.println("Error");
        } finally {
            System.out.println("Finally block executed");
        }
    }
}