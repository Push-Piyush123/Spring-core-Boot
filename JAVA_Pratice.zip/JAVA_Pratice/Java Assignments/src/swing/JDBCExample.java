package swing;

import java.sql.*;

public class JDBCExample {

    public static void main(String[] args) {

        try {
            // 1. Load Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/test", "root", "root");

            Statement stmt = con.createStatement();

            // 1) Create Table
            String createTable = "CREATE TABLE IF NOT EXISTS Student (" +
                    "RollNo INT PRIMARY KEY, Name VARCHAR(50), Address VARCHAR(100))";
            stmt.executeUpdate(createTable);
            System.out.println("Table Created");

            // Insert few records
            stmt.executeUpdate("INSERT INTO Student VALUES (1,'Piyush Lende','Pune')");
            stmt.executeUpdate("INSERT INTO Student VALUES (2,'Rahul','Mumbai')");
            System.out.println("Initial Records Inserted");

            // 2) Display Records
            ResultSet rs = stmt.executeQuery("SELECT * FROM Student");
            System.out.println("\nStudent Records:");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " +
                        rs.getString(2) + " " +
                        rs.getString(3));
            }

            // 3) Insert Two Records
            stmt.executeUpdate("INSERT INTO Student VALUES (3,'Amit','Nagpur')");
            stmt.executeUpdate("INSERT INTO Student VALUES (4,'Neha','Delhi')");
            System.out.println("\nTwo Records Inserted");

            // 4) Update One Record
            stmt.executeUpdate("UPDATE Student SET Address='Pune' WHERE RollNo=2");
            System.out.println("Record Updated");

            // 5) Delete One Record
            stmt.executeUpdate("DELETE FROM Student WHERE RollNo=1");
            System.out.println("Record Deleted");

            // Display Final Records
            rs = stmt.executeQuery("SELECT * FROM Student");
            System.out.println("\nFinal Records:");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " +
                        rs.getString(2) + " " +
                        rs.getString(3));
            }

            // Close connection
            con.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}