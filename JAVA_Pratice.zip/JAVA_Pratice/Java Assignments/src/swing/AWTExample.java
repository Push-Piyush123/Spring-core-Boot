package swing;

import java.awt.*;

public class AWTExample {

    public static void main(String[] args) {

        Frame f = new Frame("AWT Example - Piyush Lende");

        f.setLayout(new FlowLayout());

        Label l = new Label("Enter Name:");
        TextField t = new TextField(20);
        Button b = new Button("Submit");

        f.add(l);
        f.add(t);
        f.add(b);

        f.setSize(300, 200);
        f.setVisible(true);
    }
}