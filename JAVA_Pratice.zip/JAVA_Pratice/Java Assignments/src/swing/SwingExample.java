package swing;

import javax.swing.*;
import java.awt.event.*;

public class SwingExample {

    public static void main(String[] args) {

        JFrame f = new JFrame("Swing Example - Piyush Lende");

        JLabel l = new JLabel("Enter Name:");
        l.setBounds(20, 20, 100, 30);

        JTextField t = new JTextField();
        t.setBounds(120, 20, 150, 30);

        JButton b = new JButton("Click");
        b.setBounds(100, 70, 80, 30);

        JLabel result = new JLabel();
        result.setBounds(20, 120, 250, 30);

        // Event Handling
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                result.setText("Hello " + t.getText() + " - Piyush Lende");
            }
        });

        // Add components
        f.add(l);
        f.add(t);
        f.add(b);
        f.add(result);

        f.setSize(300, 250);
        f.setLayout(null);
        f.setVisible(true);
    }
}