package runtime;


interface Bank {
 void rateOfInterest();
}

class SBI implements Bank {
 public void rateOfInterest() {
     System.out.println("SBI Interest Rate: 7%");
 }
}

class HDFC implements Bank {
 public void rateOfInterest() {
     System.out.println("HDFC Interest Rate: 8%");
 }
}

public class InterfaceExample3 {
 public static void main(String[] args) {

     Bank b;

     b = new SBI();
     b.rateOfInterest();

     b = new HDFC();
     b.rateOfInterest();
 }
}