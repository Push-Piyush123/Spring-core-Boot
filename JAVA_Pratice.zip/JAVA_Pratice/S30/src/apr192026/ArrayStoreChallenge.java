package apr192026;

public class ArrayStoreChallenge {
    public static void main(String[] args) {
        // A String array
        String[] words = new String[5];
        
        // Storing it in an Object array reference
        Object[] objects = words;

        // TODO: Predict what happens here
      //objects[0] = 100; // Adding an Integer to what is technically a String array
        objects[0] = "piyush";
        System.out.println("Success!");
    }
}