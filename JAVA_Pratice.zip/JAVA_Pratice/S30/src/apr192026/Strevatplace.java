package apr192026;

import java.util.Scanner;

public class Strevatplace {
	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input string to revrese at place ");
		String s=sc.nextLine();
		
		String arr[]=s.split(" ");
		
		StringBuilder sb=new StringBuilder();
		
		
		for(int i=0;i<arr.length;i++) {
			StringBuilder res=new StringBuilder();
			
			
			for(int k=arr[i].length()-1; k>=0;k--) {
				res.append(arr[i].charAt(k));
			}
			sb.append(res).append(" ");
			
			
		}
		System.out.println(sb.toString());
	}
}
