package apr192026;

import java.util.*;

public class Findduplicate {

    public static void main(String[] args) {

        HashMap<Integer, Integer> map = new HashMap<>();

        int arr[] = {1,2,3,4,5,2,3,2,2};

        for(int i = 0; i < arr.length; i++) {

            if(map.containsKey(arr[i])) {

                map.put(arr[i], map.get(arr[i]) + 1);
            }
            else {

                map.put(arr[i], 1);
            }
        }
        System.out.println('j'+'a');
     
        for(int x : map.keySet()) {

            if(map.get(x) > 1) {

                System.out.println(x);
            }
        }
    }
}