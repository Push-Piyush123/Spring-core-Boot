package apr192026;
import java.util.*;
public class Validparanthesis {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input string to check paranthesis ");
		String s=sc.nextLine();
		Stack<Character>s1=new Stack<>();
		
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='(' || ch=='{'||ch=='[') {
				s1.push(ch);
			}
			else 
			{
				if(!s1.empty()) {
			
					if(ch==')' && s1.peek()=='(') {
						s1.pop();
					}
					else if(ch==']' && s1.peek()=='[') {
						s1.pop();
					}
					else if(ch=='}' && s1.peek()=='{') {
						s1.pop();
					}
			
				}
				
		    }
			
		}
		
		if(s1.empty()) {
			System.out.println("Valid");
		}else {
			System.out.println("Not valid");
		}
	}
	
}
