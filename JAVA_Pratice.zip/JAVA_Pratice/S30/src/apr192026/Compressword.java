package apr192026;
import java.util.*;

public class Compressword {
    public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the input string to compress ");
		String s=sc.nextLine();
		
		int count=1;
		StringBuilder res=new StringBuilder();
		for(int i=1;i<s.length();i++) {
			
			
			if(s.charAt(i)==s.charAt(i-1)) {
				count++;
				
			}else {
				res.append(s.charAt(i-1)).append(count);
				count=1;
			}
		}
		res.append(s.charAt(s.length()-1)).append(count);
		System.out.println(res.toString());
		
	}
}
