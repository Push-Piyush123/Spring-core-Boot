package apr192026;

import java.util.Optional;

public class OptionalPractice {
    public static void main(String[] args) {
        //String s = null;
        String s = "PIYUSH";
        Optional<String> optional = Optional.ofNullable(s);
        System.out.println(optional.ofNullable(s));
        // Check presence
        System.out.println(optional.isPresent());

        // Safe retrieval
        System.out.println(optional.orElse("String is null"));

        // Using ifPresent
        optional.ifPresent(value -> System.out.println("Value: " + value));

        // Using orElseGet
        System.out.println(optional.orElseGet(() -> "Generated default"));
    }
}
