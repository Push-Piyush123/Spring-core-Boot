package apr192026;

public class Test {
public static void main(String[] args) {
	double d=12.3445595575;
	//System.out.println(printf("%.2f"+d););
	//System.out.printf("%.2f",d);
	String  b= String.format("%.2f", d);
	System.out.println(b);
}
}
