package practical6;
//Implement:
//
//abstract class Shape
//
//Requirements:
//
//abstract method:
//void draw()
//
//Create subclasses:
//
//Circle
//Rectangle
//
//Override:
//
//draw()
//
//Expected Output:
//
//Drawing Circle
//Drawing Rectangle

abstract class Shape{
	abstract void draw();
}
class Circle extends Shape{
	
	@Override
	void draw() {
		System.out.println("Circle is drwing");
	}
}
class Rectangle extends Shape{
	@Override
	void draw() {
		System.out.println("Recatangle is drawing");
	}
}
public class Abstraction {
public static void main(String[] args) {
	Shape s;
	s=new Circle();
	s.draw();
	s=new Rectangle();
	s.draw();
}
}
