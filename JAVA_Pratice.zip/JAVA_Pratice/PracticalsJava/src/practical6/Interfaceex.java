package practical6;

//Create a SmartPhone class that extends the abstract class SmartDevice (with variable brand, constructor, concrete method deviceInfo(), and abstract method powerOn()) and implements both interfaces Camera (takePhoto(), recordVideo()) and MusicPlayer (playMusic(), stopMusic()). Override all methods, use super.deviceInfo() and this.brand, and maintain a static counter deviceCount that increments whenever a new SmartPhone object is created.



interface Camera {

    void takePhoto();

    void recordVideo();
}

interface MusicPlayer {

    void playMusic();

    void stopMusic();
}

abstract class SmartDevice {

    String brand;

    SmartDevice(String brand) {

        this.brand = brand;
    }

    void deviceInfo() {

        System.out.println("Device Brand: " + brand);
    }

    abstract void powerOn();
}

class SmartPhone extends SmartDevice
        implements Camera, MusicPlayer {

    static int deviceCount = 0;

    SmartPhone(String brand) {

        super(brand);

        deviceCount++;
    }

    @Override
    void powerOn() {

        System.out.println(this.brand + " Smartphone is powering ON");
    }

    @Override
    public void takePhoto() {

        System.out.println("Taking Photo");
    }

    @Override
    public void recordVideo() {

        System.out.println("Recording Video");
    }

    @Override
    public void playMusic() {

        System.out.println("Playing Music");
    }

    @Override
    public void stopMusic() {

        System.out.println("Music Stopped");
    }

    void showDetails() {

        super.deviceInfo();

        System.out.println("Total Devices Created: " + deviceCount);
    }
}

public class Interfaceex {

    public static void main(String[] args) {

        SmartDevice s = new SmartPhone("Samsung");

        s.powerOn();

        Camera c = new SmartPhone("Apple");

        c.takePhoto();

        c.recordVideo();

        MusicPlayer m = new SmartPhone("OnePlus");

        m.playMusic();

        m.stopMusic();

        SmartPhone sp = new SmartPhone("Google");

        sp.showDetails();
    }
}




