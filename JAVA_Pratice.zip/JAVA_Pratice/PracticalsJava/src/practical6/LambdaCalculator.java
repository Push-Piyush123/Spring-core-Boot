package practical6;

interface Operation{
	int op(int a,int b);
}
public class LambdaCalculator {
	public static void main(String[] args) {
		Operation add = (a,b)->a+b;
		Operation sub=(a,b)->a-b;
		Operation mul=(a,b)->a*b;
		Operation div=(a,b)->{
			if(b==0) 
				throw new ArithmeticException("Cannot divide by 0");
			else return a/b;
		};
		
		System.out.println("Addition: "+add.op(10,12));
		System.out.println("substarction : "+sub.op(12,10));
		System.out.println("Multiplication :"+mul.op(3,4));
		
		try {
			
		System.out.println("division: "+div.op(10, 5));
		System.out.println("division: "+div.op(10, 0));
		
	}catch(ArithmeticException e) {
		System.out.println("Error "+e.getMessage());
	}
}
	}
