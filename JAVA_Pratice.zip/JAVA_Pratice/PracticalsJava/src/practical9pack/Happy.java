package practical9pack;

public class Happy {
 public void wish() {
	 System.out.println("Happy Birthday Push Its 20 th Birthday");
 }
}
