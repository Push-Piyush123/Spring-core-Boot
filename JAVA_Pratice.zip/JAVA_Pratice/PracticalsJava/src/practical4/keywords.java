package practical4;


//Parent Class
//Animal
//variable:
//final String type = "Animal";
//method:
//void show()
//Child Class
//Dog extends Animal
//
//Requirements:
//
//use this
//use super
//use static variable:
//static int count
//constructor initializes object
//Expected Concepts
//
//Your program should demonstrate:
//
//this.variable
//super.show()
//static shared count
//final variable usage
class Animal{
	
	final String type="animal";
	void show() {
		System.out.println("this is an type "+type);
	}
}
class Dog extends Animal{
	static int count=0;
	int dogno;
	Dog(int dogno){
		
		this.dogno=dogno;
		count++;
	}
	void showdog() {
		super.show();
		System.out.println("Dog number is "+dogno);
		System.out.println("Object count "+count);
	}
}
public class keywords {
		public static void main(String[] args) {
			Dog dog=new Dog(60);
			dog.showdog();
			System.out.println();
			Dog dog2=new Dog(90);
			dog2.showdog();
		}
}
