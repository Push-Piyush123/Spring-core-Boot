package parctical1;
import java.util.*;

//public class EvenOdd {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Scanner sc=new Scanner(System.in);
//		System.out.print("Enter Number to check ");
//		int a=sc.nextInt();
//		if(a%2==0)
//		System.out.println("Even Number");
//		else
//			System.out.println("Odd Number");
//      sc.close();
//	}
//
//}


//public class EvenOdd{
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		int a;
//		while(true) {
//			System.out.println("Enter Number (0 to quit):");
//			a=sc.nextInt();
//			if(a==0)
//				break;
//			if(a%2==0) {
//				System.out.println("Even no");
//			}else {
//				System.out.println("Odd Number");
//			}
//		}
//		sc.close();
//	}
//}



public class EvenOdd {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int a;

        while (true) {

            System.out.print("Enter Number (0 to quit): ");

            try {

                a = sc.nextInt();

                if (a == 0) {
                    System.out.println("Program terminated");
                    break;
                }

                if (a % 2 == 0) {
                    System.out.println("Even Number");
                } else {
                    System.out.println("Odd Number");
                }

            } catch (InputMismatchException e) {

                System.out.println("Invalid input! Enter integer only.");

                sc.nextLine(); // clears invalid input
            }
        }

        sc.close();
    }
}