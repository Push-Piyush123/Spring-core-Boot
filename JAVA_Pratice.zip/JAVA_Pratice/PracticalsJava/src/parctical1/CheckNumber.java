package parctical1;

import java.util.*;
//Create a menu-driven Java program:

//1. Check Even/Odd
//2. Check Positive/Negative
//3. Find Square
//4. Exit

//public class CheckNumber {
//  public static void main(String[] args) {
//	Scanner sc=new Scanner(System.in);
//	int ch;
//	int a;
//	while(true) {
//		System.out.println("Welcome to no game \n 1.check even/odd \n2.check positive/negative \n3.find square \n4.exit");
//		System.out.println("Enter number  \n");
//		try {
//		a=sc.nextInt();
//		System.out.println("Enter your choice \n");
//		ch=sc.nextInt();
//		switch(ch) {
//		case 1:if(a%2==0)
//			   System.out.println("Even number");
//		       else
//			   System.out.println("odd number");
//		       break;
//		case 2:if(a>0)
//			    System.out.println("positive number ");
//		else
//			System.out.println("negative number");
//		break;
//		case 3:System.out.println("square is :"+a*a);
//		break;
//		case 4: break;
//		}
//		if(ch==4)
//			break;
//		
//	}catch(InputMismatchException e) {
//		System.out.println("Enter only number");
//	}
//   }
//	sc.close();
//  }
//  }
//


public class CheckNumber {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int ch;
        int a;

        while (true) {

            System.out.println("\n===== MENU =====");
            System.out.println("1. Check Even/Odd");
            System.out.println("2. Check Positive/Negative");
            System.out.println("3. Find Square");
            System.out.println("4. Exit");

            try {

                System.out.print("Enter your choice: ");
                ch = sc.nextInt();

                if (ch == 4) {
                    System.out.println("Program terminated");
                    break;
                }

                System.out.print("Enter number: ");
                a = sc.nextInt();

                switch (ch) {

                    case 1:

                        if (a % 2 == 0) {
                            System.out.println("Even Number");
                        } else {
                            System.out.println("Odd Number");
                        }

                        break;

                    case 2:

                        if (a > 0) {
                            System.out.println("Positive Number");
                        } else if (a < 0) {
                            System.out.println("Negative Number");
                        } else {
                            System.out.println("Zero");
                        }

                        break;

                    case 3:

                        System.out.println("Square is: " + (a * a));
                        break;

                    default:

                        System.out.println("Invalid choice");
                }

            } catch (InputMismatchException e) {

                System.out.println("Enter integer only");
                sc.nextLine();
            }
        }

        sc.close();
    }
}