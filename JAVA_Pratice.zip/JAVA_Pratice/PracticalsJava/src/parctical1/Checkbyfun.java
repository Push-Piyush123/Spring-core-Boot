package parctical1;
//
////checkEvenOdd(int a)
////checkPositiveNegative(int a)
////findSquare(int a)
//import java.util.*;
//
//public class Checkbyfun {
//      static void checkEvenOdd(int a) {
//    	  if(a%2==0) {
//    		  System.out.println("Even no ");
//    	  }else {
//    		  System.out.println("odd no");
//    	  }
//      }
//      
//      static void checkPositiveNegative(int a) {
//    	  if (a > 0) {
//              System.out.println("Positive Number");
//          } else if (a < 0) {
//              System.out.println("Negative Number");
//          } else {
//              System.out.println("Zero");
//          }
//      }
//      
//     static void findSquare(int a) {
//    	  System.out.println("square is :"+(a*a));
//      }
//      
//      public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		try{int a=sc.nextInt();
//		checkEvenOdd(a);
//		checkPositiveNegative(a);
//		findSquare( a);
//		}catch(InputMismatchException e) {
//			System.out.println("Enter no only");
//			sc.nextLine();
//		}
//	}
//}

import java.util.*;

public class Checkbyfun {

    void checkEvenOdd(int a) {

        if(a % 2 == 0) {
            System.out.println("Even no");
        } else {
            System.out.println("Odd no");
        }
    }

    void checkPositiveNegative(int a) {

        if(a > 0) {
            System.out.println("Positive");
        }
        else if(a < 0) {
            System.out.println("Negative");
        }
        else {
            System.out.println("Zero");
        }
    }

    void findSquare(int a) {

        System.out.println("Square is: " + (a * a));
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Checkbyfun obj = new Checkbyfun();

        try {
        	System.out.println("Enter no");

            int a = sc.nextInt();

            obj.checkEvenOdd(a);

            obj.checkPositiveNegative(a);

            obj.findSquare(a);

        }
        catch(InputMismatchException e) {

            System.out.println("Enter numbers only");
        }

        sc.close();
    }
}
