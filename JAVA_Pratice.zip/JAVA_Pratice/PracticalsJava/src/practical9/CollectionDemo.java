package practical9;

import java.util.*;

public class CollectionDemo {
public static void main(String[] args) {
	ArrayList<String> al=new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Input Strings exit to Exit ");
	while(true) {
		
		String input=sc.nextLine();
		if(input.equals("exit")) {
			break;
		}
		al.add(input);
		
	}
	System.out.println("First Element "+al.get(0));
	System.out.println("size "+al.size());
	for(String s:al) {
		System.out.println(s);
	}
	if(al.contains("Piyush")) {
		System.out.println("found at index "+al.indexOf("Piyush"));
	}else {
		System.out.println("Not present");
	}
	sc.close();
}
}
