package practical9;

import java.util.*;

//Main Class
public class Main6 {

 public static void main(String[] args) {

     // LIST → Product List
     List<String> products =
         new ArrayList<>();

     products.add("Laptop");
     products.add("Mobile");
     products.add("Headphones");
     products.add("Smart Watch");

     // SET → Unique Categories
     Set<String> categories =
         new HashSet<>();

     categories.add("Electronics");
     categories.add("Accessories");
     categories.add("Electronics");

     // QUEUE → Customer Orders
     Queue<String> orders =
         new LinkedList<>();

     orders.add("Order 1 - Laptop");
     orders.add("Order 2 - Mobile");
     orders.add("Order 3 - Headphones");

     // MAP → Product ID & Name
     Map<Integer,String> productMap =
         new HashMap<>();

     productMap.put(101,"Laptop");
     productMap.put(102,"Mobile");
     productMap.put(103,"Headphones");

     // Display Product List
     System.out.println(
         "----- Product List -----");

     for(String p : products) {

         System.out.println(p);
     }

     // Display Categories
     System.out.println(
         "\n----- Product Categories -----");

     for(String c : categories) {

         System.out.println(c);
     }

     // Display Product Map
     System.out.println(
         "\n----- Product Information -----");

     for(Map.Entry<Integer,String> entry
             : productMap.entrySet()) {

         System.out.println(
             "Product ID: "
             + entry.getKey()
             + " Product Name: "
             + entry.getValue()
         );
     }

     // Process Orders
     System.out.println(
         "\n----- Processing Orders -----");

     while(!orders.isEmpty()) {

         System.out.println(
             orders.poll()
             + " Processed");
     }
 }
}