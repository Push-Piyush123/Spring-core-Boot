package practical3inheritance;


//Animal
//↓
//Dog
//↓
//BabyDog
//
//Methods:
//
//Animal → eat()
//Dog → bark()
//BabyDog → weep()

class Animal{
	void eat() {
		System.out.println("Animal eats");
	}
}

class Dog extends Animal{
	void bark() {
		System.out.println("Dog barks");
	}
}
class BabyDog extends Dog{
	@Override
	void eat() {
		System.out.println("baby eats");
	}
	void weep() {
		System.out.println("Baby dog weeps");
	}
}
public class Single {
	public static void main(String[] args) {
		BabyDog baby=new BabyDog();
		baby.eat();
		baby.bark();
		baby.weep();
	}
		
}
