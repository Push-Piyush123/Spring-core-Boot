package practical3inheritance;

//Implement:
//
//class Sports
//    play()
//
//class Football extends Sports
//class Basketball extends Sports
//class Rugby extends Sports
//
//Override:
//
//play()
//
//Each subclass should print different message.
//
//Example:
//
//Football is being played
//Basketball is being played
//Rugby is being played
class Sport {

    void play() {
        System.out.println("Sport is played");
    }
}

class Football extends Sport {

    @Override
    void play() {
        System.out.println("Football is being played");
    }
}

class Basketball extends Sport {

    @Override
    void play() {
        System.out.println("Basketball is being played");
    }
}

class Rugby extends Sport {

    @Override
    void play() {
        System.out.println("Rugby is being played");
    }
}

public class Overid {

    public static void main(String[] args) {

        Sport s;

        s = new Football();
        s.play();

        s = new Basketball();
        s.play();

        s = new Rugby();
        s.play();
    }
}