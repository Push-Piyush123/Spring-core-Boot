//package practical3inheritance;
//
////Implement:
////
////Animal
////   eat()
////
////Dog
////   bark()
////
////Cat
////   meow()
////
////Requirements:
////
////Dog inherits Animal
////Cat inherits Animal
////create Dog object
////create Cat object
////call inherited + own methods
//
//class Animal{
//	void eat() {
//		System.out.println("Animal eats");
//	}
//}
//class Dog extends Animal{
//	void bark() {
//		System.out.println("Dog barks");
//	}
//}
//class Cat extends Animal{
//	void meow() {
//		System.out.println("Cats Meow");
//	}
//}
//public class Heirarchieal {
//	public static void main(String[] args) {
//		Dog dog=new Dog();
//		dog.eat();
//		dog.bark();
//		Cat cat=new Cat();
//		cat.eat();
//		cat.meow();
//	}
//	
//	
//}
