package assignment5;

//Design a java program to demonstrate run time poly using common parent class Shape. Create subclasses as Rectangle, Circle and Triangle.
//Override the method calArea(). 
class Shape {

    void calArea() {

        System.out.println("Calculating Area");
    }
}

// Rectangle Class
class Rectangle extends Shape {

    int length = 10;
    int breadth = 5;

    void calArea() {

        int area = length * breadth;

        System.out.println("Area of Rectangle = " + area);
    }
}

// Circle Class
class Circle extends Shape {

    double radius = 7;

    void calArea() {

        double area = 3.14 * radius * radius;

        System.out.println("Area of Circle = " + area);
    }
}

// Triangle Class
class Triangle extends Shape {

    int base = 10;
    int height = 6;

    void calArea() {

        double area = 0.5 * base * height;

        System.out.println("Area of Triangle = " + area);
    }
}

// Main Class
public class Main2 {

    public static void main(String[] args) {

        // Runtime Polymorphism

        Shape s;

        s = new Rectangle();
        s.calArea();

        s = new Circle();
        s.calArea();

        s = new Triangle();
        s.calArea();
    }
}
