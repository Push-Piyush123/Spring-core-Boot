package pactical9call;
import practical9pack.Happy;

public class Callwish {
public static void main(String[] args) {
	Happy h1=new Happy();
	h1.wish();
	System.out.println("call main terminated");
}
}
