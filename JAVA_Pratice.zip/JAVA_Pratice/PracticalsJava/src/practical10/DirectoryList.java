package practical10;

import java.io.File;

public class DirectoryList {

    public static void main(String[] args) {

        File folder =new File("C:\\Users");

        if(folder.exists() && folder.isDirectory()) {

            File files[] =
                    folder.listFiles();

            System.out.println(
                    "Files and Directories:");

            for(File f : files) {

                if(f.isFile()) {

                    System.out.println(
                            "File: "
                            + f.getName());
                }
                else if(f.isDirectory()) {

                    System.out.println(
                            "Directory: "
                            + f.getName());
                }
            }
        }
        else {

            System.out.println(
                    "Invalid Directory");
        }
    }
}