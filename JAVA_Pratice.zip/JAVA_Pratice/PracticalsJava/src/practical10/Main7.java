package practical10;

import java.io.*;
import java.util.Scanner;

public class Main7 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try {

            // Accept Student Details
            System.out.println(
                "Enter Student Name:");

            String studentName =
                sc.nextLine();

            System.out.println(
                "Enter Course Name:");

            String courseName =
                sc.nextLine();

            System.out.println(
                "Enter Feedback:");

            String feedback =
                sc.nextLine();

            // Writing into file
            FileWriter fw =
                new FileWriter(
                    "feedback.txt",
                    true
                );

            fw.write(
                "Student Name: "
                + studentName + "\n"
            );

            fw.write(
                "Course Name: "
                + courseName + "\n"
            );

            fw.write(
                "Feedback: "
                + feedback + "\n"
            );

            fw.write(
                "-------------------\n"
            );

            fw.close();

            System.out.println(
                "\nFeedback Stored Successfully");

            // Reading file
            FileReader fr =
                new FileReader("feedback.txt");

            BufferedReader br =
                new BufferedReader(fr);

            String line;

            System.out.println(
                "\n----- Feedback Records -----");

            while((line = br.readLine())
                    != null) {

                System.out.println(line);
            }

            br.close();
        }

        catch(Exception e) {

            System.out.println(
                "Error: " + e);
        }

        finally {

            sc.close();
        }
    }
}