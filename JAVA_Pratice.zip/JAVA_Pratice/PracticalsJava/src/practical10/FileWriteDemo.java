package practical10;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriteDemo {

    public static void main(String[] args) {

        try {

            BufferedWriter bw =
                    new BufferedWriter(
                            new FileWriter(
                                    "sample.txt"));

            bw.write("Hello Piyush");

            bw.newLine();

            bw.write("Welcome to Java File Handling");

            bw.newLine();

            bw.write("This file is created using Java");

            bw.close();

            System.out.println("Data written successfully");
        }
        catch(IOException e) {

            System.out.println(
                    "Error: "
                    + e.getMessage());
        }
    }
}