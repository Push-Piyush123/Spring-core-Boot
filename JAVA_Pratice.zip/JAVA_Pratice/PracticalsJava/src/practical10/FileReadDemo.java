package practical10;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReadDemo {

    public static void main(String[] args) {

        try {

            BufferedReader br =
                    new BufferedReader(
                            new FileReader(
                                    "sample.txt"));

            String line;

            System.out.println("File Content:");

            while((line = br.readLine()) != null) {

                System.out.println(line);
            }

            br.close();
        }
        catch(IOException e) {

            System.out.println(
                    "Error: "
                    + e.getMessage());
        }
    }
}