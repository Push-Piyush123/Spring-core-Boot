package practcal2;
import java.util.*;
//Implement:
//
//Student Class
//
//Requirements:
//
//data members:
//roll
//name
//marks
//methods:
//input()
//display()
//constructor:
//initialize values
//public class Student {
//	int roll;
//	String name;
//	int marks;
//	Student(int roll,String name,int marks){
//		this.roll=roll;
//		this.name=name;
//		this.marks=marks;
//	}
//	Student(){}
//	void input(Scanner sc) {
//		System.out.println("Enter roll no , Name , Marks ");
//		roll=sc.nextInt();
//		sc.nextLine();    // clear input buffer
//		name=sc.nextLine();
//		marks=sc.nextInt();
//	}
//	void display() {
//		System.out.println("Roll no : "+roll);
//		System.out.println("Name : "+name);
//		System.out.println("Marks : "+marks);
//	}
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		Student s1=new Student(90,"Piyush Lende",100);
//		s1.display();
//		Student s2=new Student();
//		s2.input( sc);
//		s2.display();
//		sc.close();
//	}
//}






import java.util.Scanner;

public class Student {

    int roll;
    String name;
    double marks;

    // Default constructor
    Student() {

    }

    // Parameterized constructor
    Student(int roll, String name, double marks) {

        this.roll = roll;
        this.name = name;
        this.marks = marks;
    }

    void input() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll No: ");
        roll = sc.nextInt();

        sc.nextLine();

        System.out.print("Enter Name: ");
        name = sc.nextLine();

        System.out.print("Enter Marks: ");
        marks = sc.nextDouble();
    }

    void display() {

        System.out.println("Roll No: " + roll);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
    }

    public static void main(String[] args) {

        Student s1 = new Student(101, "Piyush", 95.5);

        System.out.println("Student initialized using constructor:");
        s1.display();

        Student s2 = new Student();

        System.out.println("\nEnter details for second student:");
        s2.input();

        System.out.println("\nStudent initialized using input():");
        s2.display();
    }
}