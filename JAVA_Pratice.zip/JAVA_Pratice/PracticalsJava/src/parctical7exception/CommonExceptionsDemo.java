package parctical7exception;

import java.io.*;
import java.util.*;

public class CommonExceptionsDemo {

    public static void main(String[] args) {

        // 1. ArithmeticException
        try {
            int a = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException: " + e);
        }

        // 2. NullPointerException
        try {
            String s = null;
            System.out.println(s.length());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: " + e);
        }

        // 3. ArrayIndexOutOfBoundsException
        try {
            int arr[] = {1, 2, 3};
            System.out.println(arr[5]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException: " + e);
        }

        // 4. StringIndexOutOfBoundsException
        try {
            String str = "Java";
            System.out.println(str.charAt(10));
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("StringIndexOutOfBoundsException: " + e);
        }

        // 5. NumberFormatException
        try {
            int num = Integer.parseInt("abc");
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException: " + e);
        }

        // 6. ClassCastException
        try {
            Object obj = "Hello";
            Integer i = (Integer) obj;
        } catch (ClassCastException e) {
            System.out.println("ClassCastException: " + e);
        }

        // 7. FileNotFoundException (Checked Exception)
        try {
            FileReader fr = new FileReader("abc.txt");
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException: " + e);
        }

        // 8. IOException (Checked Exception)
        try {
            FileWriter fw = new FileWriter("test.txt");
            fw.close();

            FileReader fr = new FileReader("test.txt");
            fr.close();

        } catch (IOException e) {
            System.out.println("IOException: " + e);
        }

        // 9. InputMismatchException
        try {
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter number:");
            int n = sc.nextInt(); // enter string instead of int

        } catch (InputMismatchException e) {
            System.out.println("InputMismatchException: " + e);
        }

        // 10. IllegalArgumentException
        try {
            Thread.sleep(-1000);
        } catch (IllegalArgumentException e) {
            System.out.println("IllegalArgumentException: " + e);
        } catch (InterruptedException e) {
            System.out.println("InterruptedException: " + e);
        }

        // Finally Block
        finally {
            System.out.println("Finally block always executes");
        }

        System.out.println("Program ended successfully");
    }
}