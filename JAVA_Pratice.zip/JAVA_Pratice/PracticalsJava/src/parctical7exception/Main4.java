package parctical7exception;

import java.util.Scanner;

//Custom Exception Class
class MinimumBalanceException extends Exception {

 MinimumBalanceException(String msg) {

     super(msg);
 }
}

//Bank Account Class
class BankAccount {

 String accHolder;
 double balance;

 // Constructor
 BankAccount(String accHolder, double balance) {

     this.accHolder = accHolder;
     this.balance = balance;
 }

 // Withdrawal Method
 void withdraw(double amount)
         throws MinimumBalanceException {

     System.out.println("\nWithdrawal Amount: " + amount);

     if((balance - amount) < 5000) {

         // throw keyword
         throw new MinimumBalanceException(
             "Minimum balance of ₹5000 must be maintained"
         );
     }

     balance = balance - amount;

     System.out.println("Withdrawal Successful");
     System.out.println("Remaining Balance = ₹" + balance);
 }
}

//Main Class
public class Main4 {

 public static void main(String[] args) {

     Scanner sc = new Scanner(System.in);

     try {

         System.out.println("Enter Account Holder Name:");

         String name = sc.nextLine();

         System.out.println("Enter Initial Balance:");

         double balance = sc.nextDouble();

         BankAccount b =
             new BankAccount(name, balance);

         System.out.println("Enter Withdrawal Amount:");

         double amount = sc.nextDouble();

         b.withdraw(amount);
     }

     // Handling Custom Exception
     catch(MinimumBalanceException e) {

         System.out.println("Custom Exception: "
                            + e.getMessage());
     }

     // Handling Wrong Input
     catch(Exception e) {

         System.out.println("Invalid Input");
     }

     finally {

         System.out.println("\nTransaction Process Completed");
     }

     sc.close();
 }
}