package parctical7exception;

import java.util.InputMismatchException;
import java.util.Scanner;

class BankAccount {

    String accountHolder;

    double balance;

    BankAccount(String accountHolder, double balance) {

        this.accountHolder = accountHolder;

        this.balance = balance;
    }

    void deposit(double amount) {

        if (amount <= 0) {

            throw new IllegalArgumentException( "Deposit amount must be positive");
        }

        balance += amount;

        System.out.println( "Balance after deposit: " + balance);
    }

    void withdraw(double amount) {

        if (amount <= 0) {

            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }

        if (amount > balance) {

            throw new ArithmeticException(
                    "Insufficient balance");
        }

        balance -= amount;

        System.out.println("Balance after withdrawal: " + balance);
    }

    void showBalance() {

        System.out.println("Current Balance: " + balance);
    }
}

public class BankingSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        BankAccount acc = new BankAccount("Piyush", 5000);

        try {

            System.out.print("Enter deposit amount: ");

            double depositAmount =
                    sc.nextDouble();

            acc.deposit(depositAmount);

            System.out.print("Enter withdrawal amount: ");

            double withdrawAmount =
                    sc.nextDouble();

            acc.withdraw(withdrawAmount);

            acc.showBalance();

        }
        catch(InputMismatchException e) {

            System.out.println(
                    "Invalid input. Enter numbers only.");
        }
        catch(IllegalArgumentException e) {

            System.out.println(
                    "Error: " + e.getMessage());
        }
        catch(ArithmeticException e) {

            System.out.println(
                    "Error: " + e.getMessage());
        }
        finally {

            System.out.println(
                    "Transaction completed");
        }

        sc.close();
    }
}