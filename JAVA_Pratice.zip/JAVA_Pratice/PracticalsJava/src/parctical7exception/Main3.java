package parctical7exception;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Main3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int a, b;
        int marks[] = {85, 90, 78, 88, 92};

        try {

            // Input numbers
            System.out.println("Enter first number:");
            a = sc.nextInt();

            System.out.println("Enter second number:");
            b = sc.nextInt();

            // Division
            int result = a / b;

            System.out.println("Division Result = " + result);

            // Array index input
            System.out.println("Enter array index to access marks:");

            int index = sc.nextInt();

            System.out.println("Marks = " + marks[index]);
        }

        // Division by zero
        catch(ArithmeticException e) {

            System.out.println("Error: Cannot divide by zero");
        }

        // Invalid array index
        catch(ArrayIndexOutOfBoundsException e) {

            System.out.println("Error: Invalid array index");
        }

        // Wrong datatype input
        catch(InputMismatchException e) {

            System.out.println("Error: Invalid input type");
        }

        // Any other exception
        catch(Exception e) {

            System.out.println("General Exception: " + e);
        }

        // Always executes
        finally {

            System.out.println("Program Executed Successfully");
        }

        sc.close();
    }
}