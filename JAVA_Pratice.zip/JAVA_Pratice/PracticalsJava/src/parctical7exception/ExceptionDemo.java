package parctical7exception;

import java.io.*;
import java.util.*;

class ExceptionDemo {

    // throws keyword
    // Method declares possible IOException
    static void readFile() throws IOException {

        FileReader fr = new FileReader("demo.txt");

        System.out.println("File opened successfully");

        fr.close();
    }

    // throw keyword
    static void checkAge(int age) {

        if(age < 18) {

            // manually throwing exception
            throw new ArithmeticException("Age less than 18");
        }

        System.out.println("Eligible for voting");
    }

    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);

        try {

            // TRY BLOCK
            // risky code

            System.out.println("Enter first number:");
            int a = sc.nextInt();

            System.out.println("Enter second number:");
            int b = sc.nextInt();

            // ArithmeticException possible
            int result = a / b;

            System.out.println("Division = " + result);

            // throw keyword demo
            System.out.println("Enter age:");
            int age = sc.nextInt();

            checkAge(age);
            
         // ArrayIndexOutOfBoundsException possible
            int arr[] = {10,20,30};

            System.out.println(arr[5]);

            // throws keyword demo
            readFile();

            

        }

        // catch block 1
        catch(ArithmeticException e) {

            System.out.println("Arithmetic Exception handled");

            System.out.println(e.getMessage());
        }

        // catch block 2
        catch(InputMismatchException e) {

            System.out.println("Invalid input type");

            System.out.println(e);
        }

        // catch block 3
        catch(ArrayIndexOutOfBoundsException e) {

            System.out.println("Array index invalid");
        }

        // catch block 4
        catch(IOException e) {

            System.out.println("File handling problem");

            System.out.println(e);
        }

        // parent/general catch
        catch(Exception e) {

            System.out.println("General Exception");

            System.out.println(e);
        }

        // finally block
        finally {

            System.out.println("Finally block always executes");

            sc.close();

            System.out.println("Scanner resource closed");
        }

        System.out.println("Program continues normally");
    }
}