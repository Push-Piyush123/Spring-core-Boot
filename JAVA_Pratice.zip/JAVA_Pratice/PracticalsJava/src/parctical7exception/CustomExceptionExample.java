package parctical7exception;

// Custom exception class

class InvalidAgeException extends Exception {
	
    InvalidAgeException(String message) {
        super(message);
    }
}

public class CustomExceptionExample {

    // Method that checks age and throws custom exception
    static void checkAge(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("Age is less than 18 - Not eligible");
        } else {
            System.out.println("Eligible for voting - Piyush Lende");
        }
    }

    public static void main(String[] args) {
        try {
            checkAge(16); // test with age 16
        } catch (InvalidAgeException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        // Try with a valid age
        try {
            checkAge(20); // test with age 20
        } catch (InvalidAgeException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
