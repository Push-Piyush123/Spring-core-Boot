package parctical7exception;

import java.util.Scanner;

//Addition Thread
class Addition extends Thread {

 int a, b;

 Addition(int a, int b) {

     this.a = a;
     this.b = b;
 }

 public void run() {

     int result = a + b;

     System.out.println("Addition = " + result);
 }
}

//Subtraction Thread
class Subtraction extends Thread {

 int a, b;

 Subtraction(int a, int b) {

     this.a = a;
     this.b = b;
 }

 public void run() {

     int result = a - b;

     System.out.println("Subtraction = " + result);
 }
}

//Multiplication Thread
class Multiplication extends Thread {

 int a, b;

 Multiplication(int a, int b) {

     this.a = a;
     this.b = b;
 }

 public void run() {

     int result = a * b;

     System.out.println("Multiplication = " + result);
 }
}

//Division Thread
class Division extends Thread {

 int a, b;

 Division(int a, int b) {

     this.a = a;
     this.b = b;
 }

 public void run() {

     try {

         int result = a / b;

         System.out.println("Division = " + result);
     }

     catch(ArithmeticException e) {

         System.out.println("Cannot Divide By Zero");
     }
 }
}

//Main Class
public class Main5 {

 public static void main(String[] args) {

     Scanner sc = new Scanner(System.in);

     System.out.println("Enter First Number:");

     int a = sc.nextInt();

     System.out.println("Enter Second Number:");

     int b = sc.nextInt();

     // Creating Threads
     Addition t1 = new Addition(a,b);

     Subtraction t2 = new Subtraction(a,b);

     Multiplication t3 =
         new Multiplication(a,b);

     Division t4 = new Division(a,b);

     // Starting Threads
     t1.start();
     t2.start();
     t3.start();
     t4.start();

     sc.close();
 }
}