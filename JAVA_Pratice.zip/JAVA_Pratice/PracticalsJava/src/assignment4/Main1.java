package assignment4;

//Problem Statement 1: Sports management system maintains info about different sports all sport activities belongs to same Sports 
//academy so the academy name should be shared by all sports objects(Static keyword) ii) each sport activity has a unique activity code
//which must not be changed once assigned iii) While creating sport object constructor parameters have the same name as instance variable, 
//it should differentiate iv) a specific sport such as football is a special type of class which inherits common sport details and may
//include additional info v) the child class must be able to call parent class constructor and methods 
//vi) design an implement a java program to demonstrate the use of static final super and this keywords

//public class Sports {
//	static String academy="MIT";
//	String type="sport";
//	double fund;
//	Sports(double fund){
//		this.fund=fund;
//	}
//	
//	
//public static void main(String[] args) {
//	Sports s=new Football(1234,12,1234.00);
//	s.show();
//	System.out.println();
//}
//}
//
//class Football extends Sports{
//	int playercount;
//	final int activitycode;
//	Football(int activitycode,int playercount,double fund){
//		super(fund);
//		this.playercount=playercount;
//		this.activitycode=activitycode;
//	}
//	void show() {
//		System.out.println("Acadmey is "+academy);
//		System.out.println("Football");
//	}
//}



class Sports {

    // static variable shared by all objects
    static String academy = "MIT";

    // instance variables
    String type;
    double fund;

    // constructor
    Sports(String type, double fund) {

        // this keyword
        this.type = type;
        this.fund = fund;
    }

    // parent method
    void displaySports() {

        System.out.println("Academy Name: " + academy);
        System.out.println("Sport Type: " + type);
        System.out.println("Fund: " + fund);
    }
}

class Football extends Sports {

    int playerCount;

    // final variable
    final int activityCode;

    Football(int activityCode, int playerCount,
             String type, double fund) {

        // super keyword calls parent constructor
        super(type, fund);

        // this keyword
        this.playerCount = playerCount;

        // final variable initialization
        this.activityCode = activityCode;
    }

    void show() {

        // calling parent method using super
        super.displaySports();

        System.out.println("Activity Code: " + activityCode);
        System.out.println("Player Count: " + playerCount);
    }
}

public class Main1 {

    public static void main(String[] args) {

        Football f =
            new Football(101,11,"Football",50000);

        f.show();
    }
}