package assignment4;
//Problem Statement 2: Banking system
//A banking system maintains info about customer accounts 
//i) all bank accounts belongs to same bank so the bank name should be shared by all accounts
//ii) each account has unique account number which must not be changed once assigned
//iii) while creating an account constructor parameters have the same name as instance variables, differentiate them
//iv) a saving account is a special type of bank account which inherits common bank account details but also stores additional info like interest rate
//v) child class must be able to call parent class constructor and methods
//design and implement java program to demonstrate the use of static this final and super keywords
// Parent Class
class BankAccount {

    // static variable shared by all accounts
    static String bankName = "State Bank of India";

    String accHolder;
    double balance;

    // final variable
    final int accNo;

    // Constructor
    BankAccount(String accHolder,
                double balance,
                int accNo) {

        // this keyword
        this.accHolder = accHolder;
        this.balance = balance;
        this.accNo = accNo;
    }

    // Parent method
    void displayAccount() {

        System.out.println("Bank Name: " + bankName);
        System.out.println("Account Holder: " + accHolder);
        System.out.println("Account Number: " + accNo);
        System.out.println("Balance: " + balance);
    }
}

// Child Class
class SavingAccount extends BankAccount {

    double interestRate;

    // Constructor
    SavingAccount(String accHolder,
                  double balance,
                  int accNo,
                  double interestRate) {

        // super keyword
        super(accHolder, balance, accNo);

        // this keyword
        this.interestRate = interestRate;
    }

    // Child method
    void showSavingAccount() {

        // calling parent method using super
        super.displayAccount();

        System.out.println("Interest Rate: "
                           + interestRate + "%");
    }
}

// Main Class
public class Main {

    public static void main(String[] args) {

        SavingAccount s1 =
            new SavingAccount(
                "Piyush",
                50000,
                101,
                7.5
            );

        s1.showSavingAccount();
    }
}