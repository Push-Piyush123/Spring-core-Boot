package practical8thread;


class NumberTask implements Runnable {

    @Override
    public void run() {

        for(int i = 1; i <= 5; i++) {

            System.out.println(
                    "Number Thread: " + i);
        }
    }
}

class LetterTask implements Runnable {

    @Override
    public void run() {

        for(char ch = 'A'; ch <= 'E'; ch++) {

            System.out.println(
                    "Letter Thread: " + ch);
        }
    }
}

public class RunnableDemo  {

    public static void main(String[] args) throws InterruptedException {

        NumberTask n1 = new NumberTask();

        LetterTask l1 = new LetterTask();

        Thread t1 = new Thread(n1);

        Thread t2 = new Thread(l1);

        t1.start();
        t2.start();
        t2.join();
       // Thread.sleep(2000);
       
        
    }
}
