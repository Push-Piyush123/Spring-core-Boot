package practical8thread;

//class Mythread extends Thread{
//	@Override
//	public void run() {
//		System.out.println("Hello world");
//	}
//}
//public class HelloThread {
//public static void main(String[] args) throws Exception {
//	Mythread t1=new Mythread();
//	t1.start();
//	Thread.sleep(2000);
//	System.out.println(Thread.currentThread().getName() +"terminated");
//}
//}

class Mythread implements Runnable{
	@Override
	public void run() {
		System.out.println("Hello world");
	}
}
public class HelloThread {
public static void main(String[] args) throws Exception {
	Mythread t1=new Mythread();
	Thread T1=new Thread(t1);
	T1.start();
	Thread.sleep(2000);
	System.out.println(Thread.currentThread().getName() +"   Thread terminated");
}
}
