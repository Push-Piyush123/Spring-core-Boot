package practical8thread;

//class Eventhread extends Thread{
//	public void run() {
//		for(int i=0;i<20;i++) {
//			if(i%2==0)
//			System.out.println("T1 "+i);
//		}
//	}
//}
//class Oddthread extends Thread{
//	public void run() {
//		for(int i=0;i<20;i++) {
//			if(i%2!=0) {
//				System.out.println("T2 "+i);
//			}
//		}
//	}
//}
//public class EvenOdd {
//public static void main(String[] args) {
//	Eventhread T1=new Eventhread();
//	Oddthread T2=new Oddthread();
//	T1.start();
//	T2.start();
//}
//}

class Eventhread implements Runnable{
	public void run() {
		for(int i=0;i<20;i++) {
			if(i%2==0)
			System.out.println("T1 "+i);
		}
	}
}
class Oddthread implements Runnable{
	public void run() {
		for(int i=0;i<20;i++) {
			if(i%2!=0) {
				System.out.println("T2 "+i);
			}
		}
	}
}
public class EvenOdd {
public static void main(String[] args) {
	Eventhread n1=new Eventhread();
	Oddthread n2=new Oddthread();
	Thread T1=new Thread(n1);
	Thread T2=new Thread(n2);
	T1.start();
	T2.start();
}
}
