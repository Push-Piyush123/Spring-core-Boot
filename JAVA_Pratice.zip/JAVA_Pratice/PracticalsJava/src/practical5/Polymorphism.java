package practical5;
//Implement:
//
//Vehicle
//   speedUp()
//
//Car
//   override speedUp()
//
//Bicycle
//   override speedUp()
//
//Use:

class Vehicle {

    void speedUp() {
        System.out.println("Vehicle speed increasing");
    }
}

class Car extends Vehicle {

    @Override
    void speedUp() {
        System.out.println("Car speeds up quickly");
    }
}

class Bicycle extends Vehicle {

    @Override
    void speedUp() {
        System.out.println("Bicycle speeds up slowly");
    }
}

public class Polymorphism {

    public static void main(String[] args) {

        Vehicle v;

        v = new Car();
        v.speedUp();

        v = new Bicycle();
        v.speedUp();
    }
}