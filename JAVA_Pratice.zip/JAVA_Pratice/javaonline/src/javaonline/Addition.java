package javaonline;

public class Addition {
    int x, y;

    public Addition(int a, int b) {
        x = a;
        y = b;
    }

    public void sum() {
        System.out.println("Sum : " + (x + y));
    }

    public static void main(String[] args) {
        Addition obj = new Addition(10, 20);
        obj.sum();
    }
}