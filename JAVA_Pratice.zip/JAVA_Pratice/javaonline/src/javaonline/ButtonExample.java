package javaonline;

import javax.swing.*;      
import java.awt.*;      

public class ButtonExample {    
    ButtonExample() {    
        JFrame f = new JFrame("Button Example");            

        // Load and scale the image to a bigger size
        ImageIcon icon = new ImageIcon("C:/Users/Rudra/Pictures/M.jpg");
        Image img = icon.getImage();
        Image scaledImg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH); // Bigger size
        JButton b = new JButton(new ImageIcon(scaledImg));    

        b.setBounds(50, 50, 300, 300);   // Bigger button area    
        f.add(b);    
        f.setSize(500, 500);             // Increase frame size too    
        f.setLayout(null);    
        f.setVisible(true);    
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
    }         

    public static void main(String[] args) {    
        new ButtonExample();    
    }    
}
