package com.example.Course_Service.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Course_Service.entity.Course;

public interface CourseDao extends JpaRepository<Course,Long> {

}
