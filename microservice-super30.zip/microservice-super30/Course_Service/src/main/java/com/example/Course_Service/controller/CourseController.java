package com.example.Course_Service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Course_Service.entity.Course;
import com.example.Course_Service.service.CourseService;

@RestController
@RequestMapping("/course")
public class CourseController {
	
	@Autowired
	private CourseService courseservice;
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to CourseService";
	}
	
	@PostMapping("/add")
	public Course addCourse( @RequestBody Course course) {
		return courseservice.addCourse(course);
	}
	
	@GetMapping("/get")
	public List<Course> getAllCourses(){
		return courseservice.getAllCourse();
	}
	
	@GetMapping("/{id}")
	public Course getCourse(@PathVariable Long id) {
		return courseservice.getCourse(id);
	}
}
