package com.example.Course_Service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Course_Service.dao.CourseDao;
import com.example.Course_Service.entity.Course;

@Service
public class CourseService {
	
	@Autowired
	private CourseDao coursedao;
	
	public List<Course>getAllCourse(){
		return coursedao.findAll();
	}
	
	public Course getCourse(Long cid) {
	    return coursedao.findById(cid).orElse(null);
	}
	
	public Course addCourse(Course course) {
		 coursedao.save(course);
		 return course;
	}
}
