package com.example.Course_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
