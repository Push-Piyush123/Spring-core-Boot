package com.example.Student_Service.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.Student_Service.dto.CourseDto;
import com.example.Student_Service.external.CourseClient;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CourseIntegrationService {

    private static final Logger log =
            LoggerFactory.getLogger(CourseIntegrationService.class);

    private final CourseClient courseClient;

    public CourseIntegrationService(CourseClient courseClient) {
        this.courseClient = courseClient;
    }

    @CircuitBreaker(
        name = "courseService",
        fallbackMethod = "courseUnavailable"
    )
    public CourseLookupResponse getCourse(Long courseId) {

        log.info("Calling Course Service for courseId={}", courseId);

        CourseDto course = courseClient.getCourse(courseId);

        log.info("Course Service call successful for courseId={}", courseId);

        return CourseLookupResponse.available(course);
    }

    private CourseLookupResponse courseUnavailable(
            Long courseId, Throwable ex) {

        log.error(
            "Course Service unavailable for courseId={}. Reason: {}",
            courseId, ex.toString()
        );

        return CourseLookupResponse.unavailable(
            "COURSE_SERVICE_UNAVAILABLE",
            "Course Service is currently unavailable. Please try again later."
        );
    }
}