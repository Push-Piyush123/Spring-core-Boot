
package com.example.Student_Service.service;

import com.example.Student_Service.dto.CourseDto;

public class CourseLookupResponse {

    private CourseDto course;
    private String status;
    private String message;

    public static CourseLookupResponse available(CourseDto course) {
        CourseLookupResponse response = new CourseLookupResponse();
        response.course = course;
        response.status = "AVAILABLE";
        response.message = "Course details fetched successfully";
        return response;
    }

    public static CourseLookupResponse unavailable(
            String status, String message) {

        CourseLookupResponse response = new CourseLookupResponse();
        response.status = status;
        response.message = message;
        return response;
    }

    public CourseDto getCourse() {
        return course;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}