package com.example.Student_Service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class Student {
	@Id
	private Long student_id;
	private String student_name;
	private Long course_id;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Long student_id, String student_name, Long course_id) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.course_id = course_id;
	}
	public Long getStudent_id() {
		return student_id;
	}
	public void setStudent_id(Long student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public Long getCourse_id() {
		return course_id;
	}
	public void setCourse_id(Long course_id) {
		this.course_id = course_id;
	}
	
}
