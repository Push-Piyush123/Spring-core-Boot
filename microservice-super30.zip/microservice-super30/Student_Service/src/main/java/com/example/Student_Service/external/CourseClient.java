package com.example.Student_Service.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Student_Service.dto.CourseDto;

//@FeignClient(name="course-service",url="http://localhost:8085")   -- for only feingclient
@FeignClient(name="course-service")   // for service registry
public interface CourseClient {
	
	@GetMapping("/course/{cid}")
    CourseDto getCourse(@PathVariable Long cid);
	
}
