package com.example.Student_Service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Student_Service.dto.StudentResponse;
import com.example.Student_Service.entity.Student;
import com.example.Student_Service.service.StudentService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private StudentService studentservice;
	
	@Operation(summary = "get All students info",description = "This gives students details")
	@GetMapping("/get")
	public List<Student>getAllStudent(){
		return studentservice.getAllStudent();
	}	
	
	@GetMapping("/get/{id}")
	public StudentResponse getStudentbyId(@PathVariable Long id) {
		return studentservice.getStudentbyId(id);
	}
	
	@PostMapping("/add")
	public Student addStudent(@ RequestBody Student student) {
		return studentservice.addStudent(student);
	}
	
}
