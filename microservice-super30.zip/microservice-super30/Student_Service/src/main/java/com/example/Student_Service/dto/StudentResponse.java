//package com.example.Student_Service.dto;
//
//public class StudentResponse {
//	
//	private Long student_id;
//	private String student_name;
//	
//	private CourseDto coursedto;
//
//	public StudentResponse(Long student_id, String student_name, CourseDto coursedto) {
//		super();
//		this.student_id = student_id;
//		this.student_name = student_name;
//		this.coursedto = coursedto;
//	}
//
//	public StudentResponse() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Long getStudent_id() {
//		return student_id;
//	}
//
//	public void setStudent_id(Long student_id) {
//		this.student_id = student_id;
//	}
//
//	public String getStudent_name() {
//		return student_name;
//	}
//
//	public void setStudent_name(String student_name) {
//		this.student_name = student_name;
//	}
//
//	public CourseDto getCoursedto() {
//		return coursedto;
//	}
//
//	public void setCoursedto(CourseDto coursedto) {
//		this.coursedto = coursedto;
//	}
//	
//	
//}

package com.example.Student_Service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentResponse {

    private Long student_id;
    private String student_name;
    private CourseDto coursedto;

    private String courseServiceStatus;
    private String message;

    public Long getStudent_id() {
        return student_id;
    }

    public void setStudent_id(Long student_id) {
        this.student_id = student_id;
    }

    public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public CourseDto getCoursedto() {
        return coursedto;
    }

    public void setCoursedto(CourseDto coursedto) {
        this.coursedto = coursedto;
    }

    public String getCourseServiceStatus() {
        return courseServiceStatus;
    }

    public void setCourseServiceStatus(String courseServiceStatus) {
        this.courseServiceStatus = courseServiceStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
