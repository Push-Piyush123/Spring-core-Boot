package com.example.Student_Service.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Student_Service.entity.Student;

public interface StudentDao extends JpaRepository<Student,Long> {

}
