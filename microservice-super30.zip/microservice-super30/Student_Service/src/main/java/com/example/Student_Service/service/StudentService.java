package com.example.Student_Service.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.Student_Service.Dao.StudentDao;
import com.example.Student_Service.dto.StudentResponse;
import com.example.Student_Service.entity.Student;

@Service
public class StudentService {

    private static final Logger log =
            LoggerFactory.getLogger(StudentService.class);

    private final StudentDao studentdao;
    private final CourseIntegrationService courseIntegrationService;

    public StudentService(
            StudentDao studentdao,
            CourseIntegrationService courseIntegrationService) {

        this.studentdao = studentdao;
        this.courseIntegrationService = courseIntegrationService;
    }

    public StudentResponse getStudentbyId(Long id) {

        log.info("Fetching student with id={}", id);

        Student student = studentdao.findById(id)
                .orElseThrow(() -> {
                    log.warn("Student not found with id={}", id);
                    return new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Student not found with id: " + id
                    );
                });

        StudentResponse response = new StudentResponse();

        response.setStudent_id(student.getStudent_id());
        response.setStudent_name(student.getStudent_name());

        if (student.getCourse_id() == null) {
            response.setCourseServiceStatus("NOT_ASSIGNED");
            response.setMessage("No course is assigned to this student");

            log.info("No course assigned to student id={}", id);
            return response;
        }

        CourseLookupResponse result =
                courseIntegrationService.getCourse(student.getCourse_id());

        response.setCourseServiceStatus(result.getStatus());
        response.setMessage(result.getMessage());

        if (result.getCourse() != null) {
            response.setCoursedto(result.getCourse());
        }

        log.info(
            "Student response prepared for id={}, courseStatus={}",
            id, result.getStatus()
        );

        return response;
    }

    public List<Student> getAllStudent() {
        log.info("Fetching all students");
        return studentdao.findAll();
    }

    public Student addStudent(Student student) {
        Student savedStudent = studentdao.save(student);

        log.info(
            "Student created successfully with id={}",
            savedStudent.getStudent_id()
        );

        return savedStudent;
    }
}

//package com.example.Student_Service.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import com.example.Student_Service.Dao.StudentDao;
//import com.example.Student_Service.dto.CourseDto;
//import com.example.Student_Service.dto.StudentResponse;
//import com.example.Student_Service.entity.Student;
//import com.example.Student_Service.external.CourseClient;
//
//@Service
//public class StudentService {
//	@Autowired
//	private StudentDao studentdao;
////	@Autowired
////	private RestTemplate resttemplate;
//	
//	@Autowired
//	private CourseClient courseClient;
//	
//	public StudentResponse getStudentbyId(Long id) {
//		
//		Student student=studentdao.findById(id).orElse(null);
//		
//		StudentResponse studentresponse=new StudentResponse();
//		
//		if(student.getCourse_id()!=null) {
//			
//			studentresponse.setStudent_id(student.getStudent_id());
//			studentresponse.setStudent_name(student.getStudent_name());
//			
//			//CourseDto course=resttemplate.getForObject("http://localhost:8085/course/"+student.getCourse_id(),CourseDto.class);
//			
//			CourseDto course=courseClient.getCourse(student.getCourse_id());
//			
//			studentresponse.setCoursedto(course);
//			
//		}
//		return studentresponse;
//	}
//
//	
//	public List<Student> getAllStudent() {
//		return studentdao.findAll();
//	}
//	
//	public Student addStudent(Student student) {
//		studentdao.save(student);
//		return student;
//	}
//	
//}
