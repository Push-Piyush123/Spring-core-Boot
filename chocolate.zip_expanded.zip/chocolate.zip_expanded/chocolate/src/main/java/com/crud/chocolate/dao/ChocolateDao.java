package com.crud.chocolate.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crud.chocolate.entity.Chocolate;

@Repository
public interface ChocolateDao extends JpaRepository<Chocolate,Long>{

}
