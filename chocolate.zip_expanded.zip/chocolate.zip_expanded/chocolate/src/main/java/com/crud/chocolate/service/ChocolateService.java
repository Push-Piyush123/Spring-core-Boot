//package com.crud.chocolate.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.crud.chocolate.dao.ChocolateDao;
//import com.crud.chocolate.entity.Chocolate;
//
//@Service
//public class ChocolateService {
//	
//		@Autowired
//		ChocolateDao chocolatedao;
//	
//		public List<Chocolate>getAll(){
//			return chocolatedao.findAll();
//		}
//		
//		public Chocolate  get(Long id){
//			return  chocolatedao.findById(id).orElse(null);
//			
//		}
//		
//		public Chocolate add(Chocolate chocolate) {
//			return chocolatedao.save(chocolate);
//		}
//		
//		public Chocolate update(Long id,Chocolate chocolate) {
//			 Optional<Chocolate> isexist= chocolatedao.findById(id);
//			
//			if(isexist.isPresent()) {
//				chocolate.setId(id);
//				return chocolatedao.save(chocolate);
//			}
//			return null;
//		}
//		
//		public void delete(Long id) {
//			chocolatedao.deleteById(id);
//		}
//		
//}


package com.crud.chocolate.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.chocolate.dao.ChocolateDao;
import com.crud.chocolate.entity.Chocolate;

@Service
public class ChocolateService {

    private static final Logger logger =
            LoggerFactory.getLogger(ChocolateService.class);

    @Autowired
    ChocolateDao chocolatedao;

    public List<Chocolate> getAll() {
        logger.debug("Fetching all chocolates");
        return chocolatedao.findAll();
    }

    public Chocolate get(Long id) {
        logger.debug("Fetching chocolate with ID: {}", id);
        return chocolatedao.findById(id).orElse(null);
    }

    public Chocolate add(Chocolate chocolate) {
        logger.info("Saving a new chocolate");
        Chocolate savedChocolate = chocolatedao.save(chocolate);
        logger.info("Chocolate saved successfully with ID: {}",
                savedChocolate.getId());
        return savedChocolate;
    }

    public Chocolate update(Long id, Chocolate chocolate) {
        logger.info("Updating chocolate with ID: {}", id);

        Optional<Chocolate> existing = chocolatedao.findById(id);

        if (existing.isPresent()) {
            chocolate.setId(id);
            Chocolate updatedChocolate = chocolatedao.save(chocolate);
            logger.info("Chocolate updated successfully with ID: {}", id);
            return updatedChocolate;
        }

        logger.warn("Chocolate not found for update. ID: {}", id);
        return null;
    }

    public void delete(Long id) {
        logger.info("Deleting chocolate with ID: {}", id);

        chocolatedao.deleteById(id);

        logger.info("Chocolate deleted successfully with ID: {}", id);
    }
}