//package com.crud.chocolate.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.crud.chocolate.entity.Chocolate;
//import com.crud.chocolate.service.ChocolateService;
//
//@RestController
//public class ChocolateController {
//	
//	@Autowired
//	ChocolateService chocolateservice;
//	
//	@GetMapping("/public/get/all")
//	public List<Chocolate>getall(){
//		return chocolateservice.getAll();
//	}
//	
//	@GetMapping("/public/get/{id}")
//	public Chocolate get(@PathVariable Long id){
//		return chocolateservice.get(id);
//	}
//	
//	@PostMapping("/public/add")
//	public Chocolate add(@RequestBody Chocolate chocolate) {
//		return chocolateservice.add(chocolate);
//	}
//	
//	@PutMapping("/public/update/{id}")
//	public Chocolate update(@PathVariable Long id , @RequestBody Chocolate chocolate) {
//		return chocolateservice.update(id, chocolate);
//	}
//	
//	@DeleteMapping("/public/delete/{id}")
//	public void delete(@PathVariable Long id) {
//		chocolateservice.delete(id);
//	}
//	
//}


package com.crud.chocolate.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.crud.chocolate.entity.Chocolate;
import com.crud.chocolate.service.ChocolateService;

@RestController
public class ChocolateController {

    private static final Logger logger =
            LoggerFactory.getLogger(ChocolateController.class);

    @Autowired
    ChocolateService chocolateservice;

    @GetMapping("/public/get/all")
    public List<Chocolate> getall() {
        logger.info("Request received to get all chocolates");
        return chocolateservice.getAll();
    }

    @GetMapping("/public/get/{id}")
    public Chocolate get(@PathVariable Long id) {
        logger.info("Request received to get chocolate with ID: {}", id);
        return chocolateservice.get(id);
    }

    @PostMapping("/public/add")
    public Chocolate add(@RequestBody Chocolate chocolate) {
        logger.info("Request received to add a chocolate");
        return chocolateservice.add(chocolate);
    }

    @PutMapping("/public/update/{id}")
    public Chocolate update(
            @PathVariable Long id,
            @RequestBody Chocolate chocolate) {
        logger.info("Request received to update chocolate with ID: {}", id);
        return chocolateservice.update(id, chocolate);
    }

    @DeleteMapping("/public/delete/{id}")
    public void delete(@PathVariable Long id) {
        logger.info("Request received to delete chocolate with ID: {}", id);
        chocolateservice.delete(id);
    }
}