package com.crud.chocolate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Chocolate {
		
	@Id
	private Long id;
	
	private String name;
	
	private Double price;
	
	private Double calories;

	public Chocolate(Long id, String name, Double price, Double calories) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.calories = calories;
	}

	public Chocolate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getCalories() {
		return calories;
	}

	public void setCalories(Double calories) {
		this.calories = calories;
	}
	
	
	
}
