package com.project.CarService.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Car {
	
	@Id
	private Long carId;
	private String carModel;
	private Double carPrice;
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Car(Long carId, String carModel, Double carPrice) {
		super();
		this.carId = carId;
		this.carModel = carModel;
		this.carPrice = carPrice;
	}
	public Long getCarId() {
		return carId;
	}
	public void setCarId(Long carId) {
		this.carId = carId;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public Double getCarPrice() {
		return carPrice;
	}
	public void setCarPrice(Double carPrice) {
		this.carPrice = carPrice;
	}
	
}
