package com.project.CarService.dto;

public class CarResponse {
	
	private Long carId;
	private String carModel;
	private Double carPrice;
	
	private PhoneDto phone;

	public CarResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarResponse(Long carId, String carModel, Double carPrice, PhoneDto phone) {
		super();
		this.carId = carId;
		this.carModel = carModel;
		this.carPrice = carPrice;
		this.phone = phone;
	}

	public Long getCarId() {
		return carId;
	}

	public void setCarId(Long carId) {
		this.carId = carId;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public Double getCarPrice() {
		return carPrice;
	}

	public void setCarPrice(Double carPrice) {
		this.carPrice = carPrice;
	}

	public PhoneDto getPhone() {
		return phone;
	}

	public void setPhone(PhoneDto phone) {
		this.phone = phone;
	}
	
	
}
