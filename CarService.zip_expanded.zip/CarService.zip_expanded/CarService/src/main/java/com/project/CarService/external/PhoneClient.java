package com.project.CarService.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.CarService.dto.PhoneDto;


@FeignClient(name="Phone-client",url="http://localhost:8084")
public interface PhoneClient {
		@GetMapping("/phone/get/price/{price}")
		PhoneDto getphone(@PathVariable Double price);
}
