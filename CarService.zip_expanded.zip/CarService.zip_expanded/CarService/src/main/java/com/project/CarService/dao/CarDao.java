package com.project.CarService.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.CarService.entity.Car;

@Repository
public interface CarDao extends JpaRepository<Car, Long> {

}
