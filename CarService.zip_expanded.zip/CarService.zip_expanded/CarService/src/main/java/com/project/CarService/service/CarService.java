package com.project.CarService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.CarService.dao.CarDao;
import com.project.CarService.dto.CarResponse;
import com.project.CarService.dto.PhoneDto;
import com.project.CarService.entity.Car;
import com.project.CarService.external.PhoneClient;

@Service
public class CarService {
	
	@Autowired
	CarDao cardao;
	
	@Autowired
	PhoneClient phoneclient;
	
	public CarResponse getcar(Long id) {
		Car car= cardao.findById(id).orElse(null);
		CarResponse carresponse = new CarResponse();
		
		if(car.getCarId()!=null) {
				
		carresponse.setCarId(car.getCarId());
		carresponse.setCarModel(car.getCarModel());
		carresponse.setCarPrice(car.getCarPrice());
		
		PhoneDto phone = phoneclient.getphone(car.getCarPrice());
		
		carresponse.setPhone(phone);
		
		
		}
		return carresponse;
	}
	public List<Car> getallcars() {
		return cardao.findAll();
	}
	public Car addcar(Car car) {
		cardao.save(car);
		return car;
	}

}
