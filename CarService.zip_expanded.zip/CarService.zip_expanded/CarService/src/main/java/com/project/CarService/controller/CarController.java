package com.project.CarService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.CarService.dto.CarResponse;
import com.project.CarService.entity.Car;
import com.project.CarService.service.CarService;

@RestController
@RequestMapping("/car")
public class CarController {
		
	@Autowired
	CarService carservice;
	
	@GetMapping("/home")
	public String home() {
		return "welcome to car service";
	}
	
	@GetMapping("/get/{id}")
	public CarResponse getcar(@PathVariable Long id) {
		return carservice.getcar(id);
	}
	
	@GetMapping("/get")
	public List<Car> getcars() {
		return carservice.getallcars();
	}
	
	@PostMapping("/add")
	public Car getcar(@RequestBody Car car) {
		return carservice.addcar(car);
	}
}
